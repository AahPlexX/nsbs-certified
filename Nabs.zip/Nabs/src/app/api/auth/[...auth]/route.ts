import { Auth } from "@auth/core";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import CredentialsProvider from "@auth/providers/credentials";
import bcrypt from "bcryptjs";
import { z } from "zod";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export const { auth } = Auth({
  adapter: PrismaAdapter(prisma),
  session: { 
    strategy: "jwt",
    maxAge: 7 * 24 * 60 * 60, // 7 days for security
    updateAge: 12 * 60 * 60, // 12 hours
    generateSessionToken: () => crypto.randomUUID(),
  },
  logger: {
    error: (code, ...message) => {
      console.error(code, message);
      // Add your logging service here
    },
    warn: (code, ...message) => {
      console.warn(code, message);
      // Add your logging service here
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        try {
          const validatedFields = loginSchema.parse(credentials);

          const user = await prisma.user.findUnique({
            where: { email: validatedFields.email },
            select: {
              id: true,
              email: true,
              name: true,
              password: true,
              role: true
            }
          });

          if (!user || !user.password) {
            throw new Error("Invalid credentials");
          }

          const isValid = await bcrypt.compare(validatedFields.password, user.password);

          if (!isValid) {
            throw new Error("Invalid credentials");
          }

          return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
          };
        } catch (error) {
          console.error("Auth error:", error);
          return null;
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role;
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as "ADMIN" | "STUDENT";
        session.user.lastActive = new Date().toISOString();

        // Add role-based access validation
        const isValidRole = ["ADMIN", "STUDENT"].includes(session.user.role);
        if (!isValidRole) {
          throw new Error("Invalid user role");
        }
      }
      return session;
    }
  },
  events: {
    async signIn({ user }) {
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLogin: new Date() }
      });
    }
  },
  secret: process.env.NEXTAUTH_SECRET,
});

export const config = {
  matcher: ["/api/auth/:path*"]
};