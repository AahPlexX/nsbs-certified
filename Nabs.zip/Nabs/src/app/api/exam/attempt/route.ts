
import { auth } from '@/app/api/auth/[...auth]/route';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';
import { z } from 'zod';

const examAttemptSchema = z.object({
  examId: z.string().uuid(),
  answers: z.record(z.string(), z.number().min(0).max(3)),
});

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await req.json();
    const validated = examAttemptSchema.parse(data);

    const exam = await prisma.exam.findUnique({
      where: { id: validated.examId },
      include: { questions: true }
    });

    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 });
    }

    let score = 0;
    for (const question of exam.questions) {
      if (validated.answers[question.id] === question.correctIndex) {
        score++;
      }
    }

    const passed = (score / exam.questions.length) >= 0.8;

    const attempt = await prisma.examAttempt.create({
      data: {
        userId: session.user.id,
        examId: validated.examId,
        score,
        passed,
        answers: validated.answers,
      }
    });

    return NextResponse.json({ attempt });
  } catch (error) {
    console.error('Exam attempt error:', error);
    return NextResponse.json(
      { error: 'Failed to process exam attempt' }, 
      { status: 500 }
    );
  }
}
import { auth } from '@/app/api/auth/[...auth]/route';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';
import { z } from 'zod';

const examAttemptSchema = z.object({
  examId: z.string().uuid(),
  answers: z.record(z.string(), z.number().min(0).max(3)),
});

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json(
        { error: 'Unauthorized' }, 
        { status: 401 }
      );
    }

    const data = await req.json();
    const validated = examAttemptSchema.parse(data);

    const exam = await prisma.exam.findUnique({
      where: { id: validated.examId },
      include: { questions: true }
    });

    if (!exam) {
      return NextResponse.json(
        { error: 'Exam not found' }, 
        { status: 404 }
      );
    }

    const enrollment = await prisma.enrollment.findFirst({
      where: {
        userId: session.user.id,
        courseId: exam.courseId
      }
    });

    if (!enrollment) {
      return NextResponse.json(
        { error: 'No active enrollment found' },
        { status: 400 }
      );
    }

    if (enrollment.usedTestVouchers >= enrollment.purchasedVouchers) {
      return NextResponse.json(
        { error: 'No remaining exam attempts' },
        { status: 400 }
      );
    }

    let score = 0;
    for (const question of exam.questions) {
      if (validated.answers[question.id] === question.correctIndex) {
        score++;
      }
    }

    const passed = (score / exam.questions.length) >= 0.8; // 80% passing threshold

    const attempt = await prisma.examAttempt.create({
      data: {
        userId: session.user.id,
        examId: validated.examId,
        enrollmentId: enrollment.id,
        score,
        passed,
        answers: validated.answers,
      }
    });

    await prisma.enrollment.update({
      where: { id: enrollment.id },
      data: { usedTestVouchers: { increment: 1 } }
    });

    if (passed) {
      // Generate certificate if passed
      await prisma.certificate.create({
        data: {
          userId: session.user.id,
          enrollmentId: enrollment.id,
        }
      });
    }

    return NextResponse.json({ attempt });
  } catch (error) {
    console.error('Exam attempt error:', error);
    return NextResponse.json(
      { error: 'Failed to process exam attempt' }, 
      { status: 500 }
    );
  }
}
