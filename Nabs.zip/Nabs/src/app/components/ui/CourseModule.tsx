"use client";

import { useState } from "react";
import { useCourseStore } from "@/store/courseStore";
import { ModuleCompletionDialog } from "./ModuleCompletionDialog";
import type { Module } from "@/lib/types";
import { toast } from 'react-hot-toast'; // Assumed import

interface CourseModuleProps {
  module: Module;
  isCompleted: boolean;
  onComplete: (moduleId: string) => Promise<{ success: boolean; error?: string }>; // Updated return type
}

export function CourseModule({ module, isCompleted, onComplete }: CourseModuleProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { setModuleComplete } = useCourseStore();

  const handleComplete = async () => {
    try {
      setIsSubmitting(true);
      const result = await onComplete(module.id);
      if (result.success) {
        setModuleComplete(module.id);
        setIsDialogOpen(false);
        toast.success('Module completed successfully');
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error("Failed to complete module:", error);
      toast.error(error.message || 'Failed to complete module');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-card rounded-lg p-6 mb-4">
      <h3 className="text-xl font-semibold mb-4">{module.title}</h3>
      <div className="prose prose-slate dark:prose-invert max-w-none mb-6">
        {module.content}
      </div>
      <div className="flex justify-end">
        <button
          onClick={() => setIsDialogOpen(true)}
          disabled={isCompleted || isSubmitting}
          className={`px-4 py-2 rounded-md transition-colors ${
            isCompleted 
              ? "bg-matte-gray-300 text-matte-gray-600 cursor-not-allowed"
              : "bg-primary text-white hover:bg-primary/90"
          }`}
        >
          {isCompleted ? "Completed" : "Mark Complete"}
        </button>
      </div>
      <ModuleCompletionDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onConfirm={handleComplete}
        isSubmitting={isSubmitting}
        moduleTitle={module.title}
      />
    </div>
  );
}