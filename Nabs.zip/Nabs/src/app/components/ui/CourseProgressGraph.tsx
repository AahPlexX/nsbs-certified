
"use client";

import { useEffect, useRef } from 'react';
import { useCourseStore } from '@/store/courseStore';

export function CourseProgressGraph() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { moduleProgress, totalModulesCount } = useCourseStore();

  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const completedCount = Object.values(moduleProgress).filter(m => m.completed).length;
    const percentage = (completedCount / totalModulesCount) * 100;

    // Draw progress circle
    ctx.clearRect(0, 0, 200, 200);
    ctx.beginPath();
    ctx.arc(100, 100, 80, 0, 2 * Math.PI);
    ctx.strokeStyle = '#1f1f1f';
    ctx.lineWidth = 10;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(100, 100, 80, -0.5 * Math.PI, (percentage / 100) * 2 * Math.PI - 0.5 * Math.PI);
    ctx.strokeStyle = '#0f766e';
    ctx.stroke();

    // Draw percentage text
    ctx.font = 'bold 24px Inter';
    ctx.fillStyle = '#1f1f1f';
    ctx.textAlign = 'center';
    ctx.fillText(`${Math.round(percentage)}%`, 100, 100);
  }, [moduleProgress, totalModulesCount]);

  return (
    <canvas 
      ref={canvasRef} 
      width="200" 
      height="200"
      className="mx-auto"
      role="img"
      aria-label="Course progress visualization"
    />
  );
}
"use client";

import { useEffect, useRef } from 'react';
import { useCourseStore } from '@/store/courseStore';

interface GraphPoint {
  x: number;
  y: number;
  moduleId: string;
  completed: boolean;
}

export function CourseProgressGraph() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { moduleProgress, totalModulesCount } = useCourseStore();
  
  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const completedCount = Object.values(moduleProgress).filter(m => m.completed).length;
    const percentage = (completedCount / totalModulesCount) * 100;

    // Clear canvas
    ctx.clearRect(0, 0, 200, 200);

    // Draw background circle
    ctx.beginPath();
    ctx.arc(100, 100, 80, 0, 2 * Math.PI);
    ctx.strokeStyle = '#1f1f1f';
    ctx.lineWidth = 12;
    ctx.stroke();

    // Draw progress arc
    ctx.beginPath();
    ctx.arc(100, 100, 80, -0.5 * Math.PI, (percentage / 100) * 2 * Math.PI - 0.5 * Math.PI);
    ctx.strokeStyle = '#0f766e';
    ctx.stroke();

    // Draw percentage text
    ctx.font = 'bold 24px Inter';
    ctx.fillStyle = '#1f1f1f';
    ctx.textAlign = 'center';
    ctx.fillText(`${Math.round(percentage)}%`, 100, 100);

    // Add completion status
    ctx.font = '14px Inter';
    ctx.fillText(`${completedCount}/${totalModulesCount} Complete`, 100, 130);
  }, [moduleProgress, totalModulesCount]);

  return (
    <div className="relative w-[200px] h-[200px]">
      <canvas 
        ref={canvasRef} 
        width="200" 
        height="200"
        className="relative z-10"
        role="img"
        aria-label={`Course progress: ${Object.values(moduleProgress).filter(m => m.completed).length} of ${totalModulesCount} modules completed`}
      />
    </div>
  );
}
