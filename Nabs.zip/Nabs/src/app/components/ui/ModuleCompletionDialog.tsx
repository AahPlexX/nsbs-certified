
"use client";

import { Dialog } from "@/components/ui/Dialog";
import type { DialogProps } from "@radix-ui/react-dialog";

interface ModuleCompletionDialogProps extends Omit<DialogProps, "children"> {
  onConfirm: () => Promise<void>;
  isSubmitting: boolean;
  moduleTitle: string;
  onClose: () => void;
}

export function ModuleCompletionDialog({
  isOpen,
  onClose,
  onConfirm,
  isSubmitting,
  moduleTitle,
  ...props
}: ModuleCompletionDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose} {...props}>
      <div 
        className="fixed inset-0 bg-matte-black/90 backdrop-blur-lg z-50 flex items-center justify-center transition-all duration-300 animate-in fade-in"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
        aria-describedby="dialog-desc"
      >
        <div className="bg-card p-6 rounded-lg max-w-md w-full mx-4">
          <h2 className="text-xl font-semibold mb-4">Confirm Module Completion</h2>
          <p className="mb-6">
            Are you sure you want to mark "{moduleTitle}" as complete? This action cannot be undone.
          </p>
          <div className="flex justify-end gap-4">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-md border border-muted hover:bg-muted/10 transition-colors"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              disabled={isSubmitting}
              className="px-4 py-2 rounded-md bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? "Confirming..." : "Confirm"}
            </button>
          </div>
        </div>
      </div>
    </Dialog>
  );
}
