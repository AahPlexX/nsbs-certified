
import { createClient } from '@supabase/supabase-js';
import { Database } from '@/lib/types';

if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      storageKey: 'nsbs-auth-token',
      detectSessionInUrl: true,
      flowType: 'pkce',
    },
    realtime: {
      params: {
        eventsPerSecond: 20,
      },
      presence: {
        key: 'nsbs-presence',
      },
    },
    db: {
      schema: 'public',
    },
    global: {
      headers: {
        'x-application-name': 'nsbs-platform',
      },
    },
  }
);

// Export helper for auth state persistence
export const persistSession = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
};
