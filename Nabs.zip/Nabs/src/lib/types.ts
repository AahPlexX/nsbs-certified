
import { z } from "zod"
import { courseCreationSchema } from "./validations"

export type CourseCreationInputType = z.infer<typeof courseCreationSchema>

export interface Module {
  id: string
  title: string
  content: string
  order: number
  topicId: string
  createdAt: Date
}

export interface Topic {
  id: string
  title: string
  courseId: string
  modules: Module[]
  order: number
  createdAt: Date
}

export interface Course {
  id: string
  title: string
  slug: string
  description: string
  price: number
  topics: Topic[]
  createdAt: Date
  updatedAt: Date
}
