import { create } from 'zustand';

interface CourseState {
  completedModules: string[];
  currentCourseId: string | null;
  enrollmentId: string | null;
  examStatus: 'not_started' | 'in_progress' | 'completed' | 'passed' | 'failed';
  totalModulesCount: number;
  lastCompletedAt: string | null;
  moduleProgress: Record<string, { 
    completed: boolean;
    startedAt: string;
    completedAt?: string;
    timeSpent: number;
    status: 'locked' | 'available' | 'completed';
    lastAttemptedAt?: string;
  }>;
  examAttempts: number;
  maxAllowedAttempts: number;
  remainingAttempts: number;
  lastSyncedAt: string;
  isOffline: boolean;
  currentTopicId: string | null;
  hasCompletedPrerequisites: boolean;

  setModuleComplete: (moduleId: string) => void;
  setCurrentCourse: (courseId: string) => void;
  setEnrollmentId: (enrollmentId: string) => void;
  setExamStatus: (status: CourseState['examStatus']) => void;
  setTotalModulesCount: (count: number) => void;
  resetCourseState: () => void;
  canTakeExam: () => boolean;
  getProgress: () => { completed: number; total: number; percentage: number };
  resetProgress: () => void;
}

const initialState = {
  completedModules: [],
  currentCourseId: null,
  enrollmentId: null,
  examStatus: 'not_started' as const,
  totalModulesCount: 0,
  lastCompletedAt: null,
};

export const useCourseStore = create<CourseState>((set, get) => ({
  ...initialState,

  setModuleComplete: (moduleId: string) =>
    set((state) => {
      if (state.completedModules.includes(moduleId)) {
        return state;
      }
      return {
        completedModules: [...state.completedModules, moduleId],
        lastCompletedAt: new Date().toISOString(),
      };
    }),

  setCurrentCourse: (courseId) => {
    set({ currentCourseId: courseId });
  },

  setEnrollmentId: (enrollmentId) => {
    set({ enrollmentId });
  },

  setExamStatus: (status) => {
    set({ examStatus: status });
  },

  setTotalModulesCount: (count) => {
    set({ totalModulesCount: count });
  },

  resetCourseState: () => {
    set(initialState);
  },

  canTakeExam: () => get().completedModules.length === get().totalModulesCount,

  getProgress: () => {
    const state = get();
    return {
      completed: state.completedModules.length,
      total: state.totalModulesCount,
      percentage: Math.round((state.completedModules.length / state.totalModulesCount) * 100),
    };
  },

  resetProgress: () => set({ completedModules: [], lastCompletedAt: null }),
}));