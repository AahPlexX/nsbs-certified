
import type { Config } from "tailwindcss";
import plugin from "tailwindcss/plugin";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{ts,tsx,mdx}",
    "./src/components/**/*.{ts,tsx,mdx}",
    "./src/app/**/*.{ts,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#000000',
        secondary: '#ffffff',
        matte: {
          black: '#0A0A0A',
          gray: {
            100: '#F5F5F5',
            200: '#EBEBEB',
            300: '#D6D6D6',
            400: '#B8B8B8',
            500: '#999999',
            600: '#7A7A7A',
            700: '#5C5C5C',
            800: '#3D3D3D',
            900: '#1F1F1F'
          },
          white: '#FFFFFF',
          tan: {
            100: '#F7F3E9',
            200: '#EFE6D3',
            300: '#E7D9BD',
            400: '#DFCDA7',
            500: '#D7C091',
            600: '#CEB47B',
            700: '#C6A765',
            800: '#BE9B4F',
            900: '#B68E39'
          }
        },
        matte: {
          100: "#F5F5F5",
          200: "#E5E5E5",
          300: "#D4D4D4",
          400: "#A3A3A3",
          500: "#737373",
          600: "#525252",
          700: "#404040",
          800: "#262626",
          900: "#171717",
        },
        slate: {
          light: "#F8FAFC",
          DEFAULT: "#64748B",
          dark: "#0F172A",
        },
        tan: {
          light: "#FDF4E7",
          DEFAULT: "#D4B996",
          dark: "#A47E3B",
        },
      },
      borderRadius: {
        lg: "var(--radius-lg)",
        md: "var(--radius-md)",
        sm: "var(--radius-sm)",
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"),
    plugin(({ addVariant }) => {
      addVariant("supports-hover", "@media (hover: hover)");
    }),
  ],
};

export default config;
